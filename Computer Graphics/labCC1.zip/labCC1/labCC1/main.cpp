//
//  main.cpp
//  labCC1
//
//  Created by Дмитрий Богомолов on 17.03.14.
//  Copyright (c) 2014 Dimones. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[])
{

    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}

